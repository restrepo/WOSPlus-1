<!-- mv diagram to http://interactive.blockdiag.com and links as in https://github.com/jupyter/docker-stacks -->
# WOS+
## Visual Overview
![design](./internal/inherit-diagram.svg)